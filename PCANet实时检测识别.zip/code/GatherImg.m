function [TrnData,TrnLabel] = GatherImg(path)
% Input
%   path: The path of Dataset
% Output
%   TrnData: Loaded images(Column cell array)
%   TrnLabel: corresponding images
% Description
%   For each image(ID) of each person, we construct its mirror version

path_dir = dir(path);
path_dir(1:2) = [];
num_people = length(path_dir);
index = 1;
for i=1:num_people
    images_path = sprintf('%s\\%s',path,path_dir(i).name);
    images_dir = dir(images_path);
    images_dir(1:2) = [];
    images_dir(1:length(images_dir)/2) = [];
    num_imgs = length(images_dir);
    for j=1:num_imgs
        image_path = sprintf('%s\\%s',images_path,images_dir(j).name);
        img = imread(image_path);
        [~,~,channels] = size(img);
        if(channels == 3)
            % img = (img(:,:,1) + img(:,:,2) + img(:,:,3)) / 3;
            img = double(rgb2gray(img));
        end
        TrnData{index,1} = img;
        TrnLabel{index,1} = path_dir(i).name;
        index = index + 1;
        img = flip(img,2);
        TrnData{index,1} = img;
        TrnLabel{index,1} = path_dir(i).name;
        index = index + 1;
    end
end