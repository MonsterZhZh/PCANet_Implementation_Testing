function [crop_imgs] = FaceDetCrop(Imgs,ImgSize)
% Face Detection ans Crop into 150*80(Default)
% Input
%   Imgs: Column Cell Array
%   ImgSize: Size needed to be cropped
% Output
%   crop_imgs: Detected and Cropped imgs

%% FaceDetector by VJ
faceDetector = vision.CascadeObjectDetector();
num_imgs = length(Imgs);
crop_imgs = cell(num_imgs,1);
for i=1:num_imgs
    bboxes = step(faceDetector, uint8(Imgs{i}));
    if ~length(bboxes) == 0
        % Dealing with multiple faces, ignored since ID images
        x_center = bboxes(1) + round(bboxes(3)/2);
        width = bboxes(4) / 1.875;
        crop_bboxes = [x_center-width/2,bboxes(2),width,bboxes(4)];
        img_crop = imcrop(Imgs{i},crop_bboxes);
        img_crop = imresize(img_crop,ImgSize);
        crop_imgs{i,1} = img_crop;
    else
        fprintf('Cropped Failure at %dth images\n',i);
    end
end