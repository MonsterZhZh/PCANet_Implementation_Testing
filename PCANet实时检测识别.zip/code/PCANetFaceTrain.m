ImgSize = [150 80];
ImgFormat = 'gray';
% Getting train images and corresponding labels
[TrnData,TrnLabel] = GatherImg('D:\Workspace\PCANet\PCANet_RealTime\Dataset');
% Croping train images
[crop_imgs] = FaceDetCrop(TrnData,ImgSize);
%% PCANet Parameters Setting
PCANet.NumStages = 2;
PCANet.PatchSize = [7 7];
PCANet.NumFilters = [8 8];
PCANet.HistBlockSize = [15 13];
PCANet.BlkOverLapRatio = 0;
PCANet.Pyramid = [];
fprintf('\n ====== PCANet Parameters ======= \n')
PCANet
%% Extract PCANet
fprintf('\n ====== PCANet Extract Filters ======= \n')
% [ftrain, V,~] = PCANet_train(crop_imgs,PCANet,1);
ftrain = PCANet_FeaExt(crop_imgs,V,PCANet);
% fprintf('\n ====== Performing WPCA ======= \n')
% [U, D, ~] = mySVD(ftrain);
% U = U*diag(1./diag(D));
ftrain = U'*ftrain;
save Pch_7-7_Filts_8-8_HiBlk_15-13_OvLp_0_ftrain_sin.mat ftrain
% save Pch_7-7_Filts_8-8_HiBlk_15-13_OvLp_0_SVD_U_sin.mat U
% save Pch_7-7_Filts_8-8_HiBlk_15-13_OvLp_0_SVD_V_sin.mat V
% save TrnLabel.mat TrnLabel