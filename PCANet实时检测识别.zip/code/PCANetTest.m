ImgSize = [150 80];
ImgFormat = 'gray';
threshold = 0.970167517662048;
% load Pch_7-7_Filts_8-8_HiBlk_15-13_OvLp_0_ftrain_sin.mat
% load Pch_7-7_Filts_8-8_HiBlk_15-13_OvLp_0_SVD_U_sin.mat
% load Pch_7-7_Filts_8-8_HiBlk_15-13_OvLp_0_SVD_V_sin.mat
% load TrnLabel.mat
%% PCANet Parameters Setting
PCANet.NumStages = 2;
PCANet.PatchSize = [7 7];
PCANet.NumFilters = [8 8];
PCANet.HistBlockSize = [15 13];
PCANet.BlkOverLapRatio = 0;
PCANet.Pyramid = [];
fprintf('\n ====== PCANet Parameters ======= \n')
PCANet
%% Camera Setting
% cam_info = imaqhwinfo('winvideo');
vid = videoinput('winvideo',1,'YUY2_320x240');
set(vid,'ReturnedColorSpace','rgb');
preview(vid);
%% FaceDetector by VJ
faceDetector = vision.CascadeObjectDetector();
%% Getting frame
while(true)
    frame = getsnapshot(vid);
    frame = rgb2gray(frame);
    frame = imresize(frame,0.7);
    bboxes = step(faceDetector, frame);
    if ~length(bboxes) == 0
        % Dealing with multiple faces
        if size(bboxes,1) ~= 1
            max_index = -1;
            max_area = 0;
            for index=1:size(bboxes,1)
                if bboxes(index,3)*bboxes(index,4) > max_area
                    max_area = bboxes(index,3)*bboxes(index,4);
                    max_index = index;
                end
            end
            bboxes = bboxes(max_index,:);
        end
        x_center = bboxes(1) + round(bboxes(3)/2);
        width = bboxes(4) / 1.875; % height/width = 150 / 80
        crop_bboxes = [x_center-width/2,bboxes(2),width,bboxes(4)];
        img_crop = imcrop(frame,crop_bboxes);
        %% Face Recognition
        [height,width,~] = size(img_crop);
        if (height < 100) && (width < 100)
            fprintf('This may not a Face!!!\n');
        else
            img_crop = imresize(img_crop,ImgSize);
            imshow(img_crop);
            img_crop = double(img_crop);
            TestData_ImgCell = {img_crop};
            ftest = PCANet_FeaExt(TestData_ImgCell,V,PCANet);
            ftest = U'*ftest;
            %% Nearest neighbor matching
            min_distance = 1000;
            predict_index = -1;
            num_people = size(ftrain,2);
            for i=1:num_people
                distance = pdist2(ftest',ftrain(:,i)','cosine');
                if distance < min_distance
                    min_distance = distance;
                    predict_index = i;
                end
            end
            if min_distance < threshold
                fprintf('Recognize as %s\n',TrnLabel{predict_index});
            else
                fprintf('No Matching!!!\n');
            end
        end
    else
        fprintf('No Faces have been detected!!!\n');
    end
end