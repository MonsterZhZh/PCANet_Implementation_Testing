function images = get_images(images_pair)
% input:
%   type: cell array
%   content: Each row contains matched&mismatched image pairs(# of column = 2)
% output:
%   type: double array(uint8 used for imshow;double used for storage and caculate)
%   content: Each image represents by a column vector
images = [];
[num,pair] = size(images_pair);
% Each pair of images sorting by columns
for i=1:num
    for j=1:pair
        X = read_image(images_pair{i,j});
        images = [images,X];
    end
end