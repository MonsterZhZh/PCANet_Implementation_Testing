function im = im2col_general(varargin)
% 

NumInput = length(varargin);
InImg = double(varargin{1});
patchsize12 = double(varargin{2}); 

z = size(InImg,3);
im = cell(z,1);
if NumInput == 2
    for i = 1:z
        im{i} = im2colstep(InImg(:,:,i),patchsize12)';
        im{i} = single(im{i});
    end
else
    for i = 1:z
        im{i} = im2colstep(InImg(:,:,i),patchsize12,varargin{3})';
        im{i} = single(im{i});
    end 
end
im = [im{:}]';
    
    