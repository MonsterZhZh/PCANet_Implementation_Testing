%% Using View1 to determine the threshold
% Get path of test image pairs
[same_test_pair,diff_test_pair] = getlfwPairsDev('D:\\Workspace\\Opencv\\Dataset\\others\\lfw\\pairsDevTest.txt','D:\\Workspace\\Opencv\\Dataset\\others\\lfw');
test_pairs = [same_test_pair;diff_test_pair];
test_labels = [ones(size(same_test_pair,1),1);zeros(size(diff_test_pair,1),1)];
% Forming test distances
distance = zeros(size(test_pairs,1),1);
for iter_samples=1:size(test_pairs,1)
    % src_LBP_img = lbp_nonuniform(double(imread(test_pairs{iter_samples,1})), 1, 8);
    % dst_LBP_img = lbp_nonuniform(double(imread(test_pairs{iter_samples,2})), 1, 8);
    % src_hist = spatialhistogram(src_LBP_img, 8, 8, 256);
    % dst_hist = spatialhistogram(dst_LBP_img, 8, 8, 256);
    mapping = getmapping(8,'u2');
    src_hist = lbp(double(imread(test_pairs{iter_samples,1})),1,8,mapping,'h');
    dst_hist = lbp(double(imread(test_pairs{iter_samples,2})),1,8,mapping,'h');
    distance(iter_samples) = chi_square(src_hist,dst_hist);
    % distance(iter_samples) = pdist2(src_hist,dst_hist);
end
%   Normaliza distances by min-max
min = min(distance);
max = max(distance);
for iter_pair=1:size(distance,1)
    distance(iter_pair) = (distance(iter_pair) - min) / (max - min);
end
% Searching for optimal threshold
optimal_threshold = 0;
optimal_accuracy = 0;
% normed_chi_square distance
for threshold=0.0001:0.0001:1
% for threshold=0.0001:0.0001:2
    correct_count = 0;
    for iter_samples=1:size(distance,1)
        if distance(iter_samples) <= threshold
            predict = 1;
        else
            predict = 0;
        end
        if predict == test_labels(iter_samples)
            correct_count = correct_count + 1;
        end
    end
    current_accuracy = correct_count / size(distance,1);
    if current_accuracy > optimal_accuracy
        optimal_accuracy = current_accuracy;
        optimal_threshold = threshold;
    end
end
% Return to the same range of original Euclidean distance
optimal_threshold = optimal_threshold * (max - min) + min;