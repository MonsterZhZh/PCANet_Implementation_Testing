% Get path of train image pairs
[same_train_pair,diff_train_pair] = getlfwPairsDev('D:\\Workspace\\Opencv\\Dataset\\others\\lfw-a-cropped\\pairsDevTrain.txt','D:\\Workspace\\Opencv\\Dataset\\others\\lfw-a-cropped');
ImgSize = [150 80];
ImgFormat = 'gray';
%% PCANet Parameters Setting
PCANet.NumStages = 2;
PCANet.PatchSize = [7 7];
PCANet.NumFilters = [8 8];
PCANet.HistBlockSize = [15 13];
PCANet.BlkOverLapRatio = 0;
PCANet.Pyramid = [];
fprintf('\n ====== PCANet Parameters ======= \n')
PCANet
%% Extract PCANet
% Get train images
train_images = get_images([same_train_pair;diff_train_pair]);
train_images = single(train_images);
% % Computing PCA Filters Bank V from the training set of View1
TrnData_ImgCell = mat2imgcell(train_images,ImgSize(1),ImgSize(2),ImgFormat);
clear train_images
fprintf('\n ====== PCANet Extract Filters ======= \n')
[ftrain, V,~] = PCANet_train(TrnData_ImgCell,PCANet,1);
clear TrnData_ImgCell
save Pch_15-15_Filts_8-8_HiBlk_15-13_OvLp_0_V_sin.mat V
save Pch_15-15_Filts_8-8_HiBlk_15-13_OvLp_0_ftrain_sin.mat ftrain
fprintf('\n ====== Performing WPCA ======= \n')
[U, D, ~] = mySVD(ftrain,3200);
clear ftrain
U = U*diag(1./diag(D));
save Pch_15-15_Filts_8-8_HiBlk_15-13_OvLp_0_SVD_U-3200_sin.mat U
save Pch_15-15_Filts_8-8_HiBlk_15-13_OvLp_0_SVD_D-3200_sin.mat D
%% PCANet Feature Extraction and Testing
% Get test images
[same_test_pair,diff_test_pair] = getlfwPairsDev('D:\\Workspace\\Opencv\\Dataset\\others\\lfw-a-cropped\\pairsDevTest.txt','D:\\Workspace\\Opencv\\Dataset\\others\\lfw-a-cropped');
test_images = get_images([same_test_pair;diff_test_pair]);
test_images = single(test_images);
TestData_ImgCell = mat2imgcell(test_images,ImgSize(1),ImgSize(2),ImgFormat);
clear test_images
% Forming test labels
test_labels = [ones(size(same_test_pair,1),1);zeros(size(diff_test_pair,1),1)];
% train_labels = [ones(size(same_train_pair,1),1);zeros(size(diff_train_pair,1),1)];
clear same_train_pair
clear diff_train_pair
%   Forming test distances
distance = zeros(size(TestData_ImgCell,1)/2,1);
% distance = zeros(size(TrnData_ImgCell,1)/2,1);
%%       ***Cosine distance***
%   Range:[0,2]
fprintf('\n ====== Forming PCANet distance ======= \n')
for iter_samples=1:2:size(TestData_ImgCell,1)
    ftest1 = U'*PCANet_FeaExt(TestData_ImgCell(iter_samples),V,PCANet);
    ftest2 = U'*PCANet_FeaExt(TestData_ImgCell(iter_samples+1),V,PCANet);
    distance((iter_samples+1)/2) = pdist2(ftest1',ftest2','cosine');
    if 0==mod(iter_samples+1,100)
        fprintf('\n %dth samples \n',iter_samples);
    end
end
clear TestData_ImgCell
% clear TrnData_ImgCell
fprintf('\n ====== PCANet Saving distance ======= \n')
save Pch_15-15_Filts_8-8_HiBlk_15-13_OvLp_0_dist-dvlp-test_U-3200_sin.mat distance test_labels
%% Searching for optimal threshold on test set of View1
optimal_threshold = 0;
optimal_accuracy = 0;
% Cosine distance
for iter=1:size(distance,1)
    threshold = distance(iter);
    correct_count = 0;
    for iter_samples=1:size(distance,1)
        if distance(iter_samples) <= threshold
            predict = 1;
        else
            predict = 0;
        end
        if predict == test_labels(iter_samples)
            correct_count = correct_count + 1;
        end
    end
    current_accuracy = correct_count / size(distance,1);
    if 0==mod(iter,100)
        fprintf('\n Until %dth samples, current_accuracy is %.2f%% \n',[iter 100*current_accuracy]);
    end
    if current_accuracy > optimal_accuracy
        optimal_accuracy = current_accuracy;
        optimal_threshold = threshold;
    end
end
save Pch_15-15_Filts_8-8_HiBlk_15-13_OvLp_0_opt-dvlp-test_U-3200_sin.mat optimal_accuracy optimal_threshold
