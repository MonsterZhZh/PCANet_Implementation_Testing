% Predefined distance
% chi_square threshold
% threshold = 33251.2190456130;
% chi_square uniform
threshold = 11687.1662942108;
% cosine threshold
% threshold = 0.3941;
% Euclidean distance
% threshold = 1900.44272515939;
load same_pair.mat
load diff_pair.mat
verification_pairs = [same_pair;diff_pair];
verification_labels = [ones(size(same_pair,1),1);zeros(size(diff_pair,1),1)];
correct_count = 0;
distance = 0;
for iter_samples=1:size(verification_pairs,1)
    % src_LBP_img = lbp_nonuniform(double(imread(verification_pairs{iter_samples,1})), 1, 8);
    % dst_LBP_img = lbp_nonuniform(double(imread(verification_pairs{iter_samples,2})), 1, 8);
    % src_hist = spatialhistogram(src_LBP_img, 8, 8, 256);
    % dst_hist = spatialhistogram(dst_LBP_img, 8, 8, 256);
    mapping = getmapping(8,'u2');
    src_hist = lbp(double(imread(verification_pairs{iter_samples,1})),1,8,mapping,'h');
    dst_hist = lbp(double(imread(verification_pairs{iter_samples,2})),1,8,mapping,'h');
    distance = chi_square(src_hist,dst_hist);
    % distance = pdist2(src_hist,dst_hist);
    if distance <= threshold
        predict_label = 1;
    else
        predict_label = 0;
    end
    if predict_label == verification_labels(iter_samples)
        correct_count = correct_count + 1;
    end
end
accuracy = correct_count / size(verification_labels,1);