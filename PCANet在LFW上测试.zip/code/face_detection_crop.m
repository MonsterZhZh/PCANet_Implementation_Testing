%% The path of dataset you want to detect and crop
load_path = 'D:\Workspace\Opencv\Dataset\others\lfw-a';
load_path_dir = dir(load_path); 
% hidden files you need to deal with
load_path_dir(1:2) = [];
load_path_dir(5750:5752) = [];
%% The path of dataset you want to save the results
save_path = 'D:\Workspace\Opencv\Dataset\others\lfw-a-cropped';
mkdir(save_path);
%% FaceDetector by VJ
faceDetector = vision.CascadeObjectDetector();
num_people = length(load_path_dir);
total = 0;
total_det_count = 0;
missing_path = 'D:\Workspace\Opencv\Dataset\others\lfw-missing-det';
mkdir(missing_path);
for i=1:num_people
    % Detect each people
    name_path = sprintf('%s\\%s',load_path,load_path_dir(i).name);
    save_name_path = sprintf('%s\\%s',save_path,load_path_dir(i).name);
    mkdir(save_name_path);
    name_path_dir = dir(name_path);
    name_path_dir(1:2) = []; % deal with hidden files
    num_each_people = length(name_path_dir);
    % Detect each image per people
    det_count_each = 0;
    for j=1:num_each_people
        image_path = sprintf('%s\\%s',name_path,name_path_dir(j).name);
        save_image_path = sprintf('%s\\%s',save_name_path,name_path_dir(j).name);
        img = imread(image_path);
        bboxes = step(faceDetector, img);
        if ~length(bboxes) == 0 
            % Dealing with multiple faces
            if size(bboxes,1) ~= 1
                max_index = -1;
                max_area = 0;
                for index=1:size(bboxes,1)
                    if bboxes(index,3)*bboxes(index,4) > max_area
                        max_area = bboxes(index,3)*bboxes(index,4);
                        max_index = index;
                    end
                end
                bboxes = bboxes(max_index,:);
            end
            x_center = bboxes(1) + round(bboxes(3)/2);
            y_center = bboxes(2) + round(bboxes(4)/2);
            crop_bboxes = [x_center-39,y_center-74,79,149];
            img_crop = imcrop(img,crop_bboxes);
            if (size(img_crop,1) ~= 150) && (size(img_crop,2) ~= 80)
                error('Image size does not match the 150*80!!!');
            end
            imwrite(img_crop,save_image_path);
            det_count_each = det_count_each + 1;
            total_det_count = total_det_count + 1;
        else
            % Saving missing detect images
            missing_folder_path = sprintf('%s\\%s',missing_path,load_path_dir(i).name);
            if ~exist(missing_folder_path)
                mkdir(missing_folder_path);
            end
            missing_image_path = sprintf('%s\\%s',missing_folder_path,name_path_dir(j).name);
            imwrite(img,missing_image_path);
        end
        total = total + 1;
    end
    fprintf('Cropping %s, cropped:%d, total:%d\n',load_path_dir(i).name,det_count_each,num_each_people);
    if det_count_each ~= num_each_people
        fprintf('%s\n',load_path_dir(i).name);
    end
end
fprintf('\ntotal cropped:%d, total:%d\n',total_det_count,total);
