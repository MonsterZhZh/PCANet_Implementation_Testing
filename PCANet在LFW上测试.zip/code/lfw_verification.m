% Use dataset of View2 to examine the performance of your predefined model
%   For using Euclidean distance to verification case, you can take the
%   predifined threshold and the percent of energy that needs to be remained
% Attention: you can not peak the test set during each runs of 10-fold
% cross-validation unless it is unsupervised.
[same_pair,diff_pair] = getlfwPairs('D:\\Workspace\\Opencv\\Dataset\\others\\lfw-a-cropped\\pairs.txt','D:\\Workspace\\Opencv\\Dataset\\others\\lfw-a-cropped');
ImgSize = 250;
ImgFormat = 'gray';
% Overall accuracy
accuracy = zeros(10,1);
% Predifined threshold
%% PCANet Parameters Setting
PCANet.NumStages = 2;
PCANet.PatchSize = [5 5];
PCANet.NumFilters = [8 8];
PCANet.HistBlockSize = [15 13];
PCANet.BlkOverLapRatio = 0;
PCANet.Pyramid = [];

fprintf('\n ====== PCANet Parameters ======= \n')
PCANet
%%   Cosine distance
threshold = 0.0;
%%
% 10-fold cross-validation divided by pairs.txt
for i=1:10
    test_idx = (i-1) * 300 + 1 : i*300;
    test_idx = test_idx';
    train_idx = 1:3000;
    train_idx = train_idx';
    train_idx(test_idx) = [];
    % Getting images by path of matched/mismatched pairs
    load same_pair.mat
    load diff_pair.mat
    train_images = get_images([same_pair(train_idx,:);diff_pair(train_idx,:)]);
    % Forming labels
    same_labels = ones(3000,1);
    diff_labels = zeros(3000,1);
    % For binary classification, this may not neccessary
    % train_labels = [same_labels(train_idx);diff_labels(train_idx)];
    test_labels = [same_labels(test_idx);diff_labels(test_idx)];
    clear same_labels
    clear diff_labels
    % train set: PCANet Feature Extraction
    TrnData_ImgCell = mat2imgcell(train_images,ImgSize,ImgSize,ImgFormat);
    ftrain = PCANet_FeaExt(TrnData_ImgCell,V,PCANet);
    fprintf('\n ====== Performing WPCA ======= \n')
    [U, D, ~] = svds(ftrain,3200);
    U = U*diag(1./diag(D)); 
    clear train_images
    clear ftrain
%     [~,V,~] = PCANet_train(TrnData_ImgCell,PCANet,1);
    clear TrnData_ImgCell
    % test set: PCANet Feature Extraction and Testing
    test_images = get_images([same_pair(test_idx,:);diff_pair(test_idx,:)]);
    clear same_pair
    clear diff_pair
    TestData_ImgCell = mat2imgcell(test_images,ImgSize,ImgSize,ImgFormat);
    clear test_images
    distance = zeros(size(TestData_ImgCell,1)/2,1);
    %% test set: Get 'Cosine' distance corresponding to each test image pairs
    for iter_samples=1:2:size(TestData_ImgCell,1)
        ftest1 = U'*PCANet_FeaExt(TestData_ImgCell(iter_samples),V,PCANet);
        ftest2 = U'*PCANet_FeaExt(TestData_ImgCell(iter_samples+1),V,PCANet);
        distance((iter_samples+1)/2) = pdist2(ftest1',ftest2','cosine');
    end
    clear TestData_ImgCell
    %%
    % Compare to predifined threshold to verification
    correct_count = 0;
    for iter_samples=1:size(distance,1)
        if distance(iter_samples) <= threshold
            predict_label = 1;
        else
            predict_label = 0;
        end 
        if predict_label == test_labels(iter_samples)
            correct_count = correct_count + 1;
        end 
    end
    accuracy(i) = correct_count/size(test_labels,1);
    clear distance
    clear test_labels
end