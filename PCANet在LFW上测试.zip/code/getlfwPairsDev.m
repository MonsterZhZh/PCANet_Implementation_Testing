function [same_pair,diff_pair] = getlfwPairsDev(txt_path,data_path)

fid = fopen(txt_path);
CC = fscanf(fid,'%d');
n_num = CC(1);

same_pair = cell(n_num,2);
diff_pair = cell(n_num,2);
% storing path of same_pair
for i=1:n_num
    CC = textscan(fid, '%s %d %d\n');
    p = CC{1};id1=CC{2};id2=CC{3};
    same_pair(i,1) = {sprintf('%s\\%s\\%s_%04d.jpg',data_path,p{1},p{1},id1)};
    same_pair(i,2) = {sprintf('%s\\%s\\%s_%04d.jpg',data_path,p{1},p{1},id2)};
end
% storing path of diff_pair
for i=1:n_num
    CC = textscan(fid, '%s %d %s %d\n');
    p1 = CC{1};id1=CC{2};p2=CC{3};id2=CC{4};
    diff_pair(i,1) = {sprintf('%s\\%s\\%s_%04d.jpg',data_path,p1{1},p1{1},id1)};
    diff_pair(i,2) = {sprintf('%s\\%s\\%s_%04d.jpg',data_path,p2{1},p2{1},id2)};
end
fclose(fid);